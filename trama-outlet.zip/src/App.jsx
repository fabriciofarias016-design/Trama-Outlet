
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import { ShoppingCart, Instagram, MessageCircle } from "lucide-react";

export default function TramaOutletHomepage() {
  return (
    <div className="min-h-screen bg-white text-gray-800 font-[Poppins] relative">
      <a
        href="https://wa.me/559299999999999?text=Olá!%20Gostaria%20de%20falar%20com%20a%20Trama%20Outlet."
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 bg-[#4C6FAE] text-white rounded-full shadow-lg p-4 hover:bg-[#3b5d94] transition flex items-center justify-center z-50"
      >
        <MessageCircle className="w-6 h-6" />
      </a>

      <header className="flex items-center justify-between px-8 py-6 border-b border-gray-100">
        <h1 className="text-2xl font-bold tracking-tight text-[#4C6FAE]">Trama Outlet</h1>
        <nav className="hidden md:flex gap-8 text-gray-700 text-sm">
          <a href="#loja" className="hover:text-[#4C6FAE] transition">Loja</a>
          <a href="#sobre" className="hover:text-[#4C6FAE] transition">Sobre</a>
          <a href="#contato" className="hover:text-[#4C6FAE] transition">Contato</a>
        </nav>
        <div className="flex gap-3">
          <Button className="bg-[#EDEAE5] text-[#4C6FAE] rounded-full px-4 py-2 text-sm flex items-center gap-2 hover:bg-[#e3e0db] transition">
            <ShoppingCart className="w-4 h-4" /> Carrinho
          </Button>
          <Button className="bg-[#4C6FAE] text-white rounded-full px-6 py-2 text-sm hover:bg-[#3b5d94] transition">Entrar</Button>
        </div>
      </header>

      <section className="px-8 md:px-20 py-20 text-center">
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-5xl font-semibold text-gray-900 mb-6"
        >
          Onde o estilo se entrelaça com o preço justo.
        </motion.h2>
        <p className="text-gray-600 max-w-2xl mx-auto mb-8">
          Moda acessível com qualidade e refinamento. Conheça nossas coleções inspiradas na leveza, elegância e conexão entre o bom gosto e o preço justo.
        </p>
        <Button className="bg-[#4C6FAE] text-white rounded-full px-8 py-3 text-base hover:bg-[#3b5d94] transition">
          Ver Coleção
        </Button>
      </section>

      <footer className="py-6 border-t border-gray-200 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} Trama Outlet — Moda inteligente e acessível.
      </footer>
    </div>
  );
}
